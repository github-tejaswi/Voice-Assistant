export default {
  plusSign: "+",
  minusSign: "-",
  currencyTL: "TL",
};
